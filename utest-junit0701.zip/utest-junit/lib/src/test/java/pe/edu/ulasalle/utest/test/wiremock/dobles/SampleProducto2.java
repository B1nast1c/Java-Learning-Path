package pe.edu.ulasalle.utest.test.wiremock.dobles;

import java.util.Map;

public class SampleProducto2 {

	private Map<String, Object> products;

	public Map<String, Object> getProducts() {
		return products;
	}

	public void setProducts(Map<String, Object> products) {
		this.products = products;
	}

	
}
