package pe.edu.ulasalle.utest.test.junit.suites.packb;

import static org.junit.jupiter.api.Assertions.*; 

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

public class TestB {

	@Test
	void testEjecutarOperacion21() {
		fail("Not yet implemented");
	}

	@Test
	@Tag("nonfun")
	void testEjecutarOperacion22() {
		fail("Not yet implemented");
	}

	@Test
	void testEjecutarOperacion23() {
		fail("Not yet implemented");
	}

}
