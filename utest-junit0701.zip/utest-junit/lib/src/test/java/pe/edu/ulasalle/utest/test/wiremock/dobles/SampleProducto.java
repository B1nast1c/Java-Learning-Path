package pe.edu.ulasalle.utest.test.wiremock.dobles;

import java.util.List;

public class SampleProducto {

	private List<Producto> products;

	public List<Producto> getProducts() {
		return products;
	}

	public void setProducts(List<Producto> products) {
		this.products = products;
	}
	
	
	
}
