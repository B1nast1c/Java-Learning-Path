package pe.edu.ulasalle.utest.test.junit.suites.packa;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TestA2 {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
