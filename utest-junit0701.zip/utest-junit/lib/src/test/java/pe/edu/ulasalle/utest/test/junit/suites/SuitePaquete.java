package pe.edu.ulasalle.utest.test.junit.suites;

import org.junit.platform.suite.api.SelectPackages; 
import org.junit.platform.suite.api.Suite;

@Suite
@SelectPackages({"pe.edu.ulasalle.utest.test.junit.suites.packa","pe.edu.ulasalle.utest.test.junit.suites.packc"})
public class SuitePaquete {

	
}
