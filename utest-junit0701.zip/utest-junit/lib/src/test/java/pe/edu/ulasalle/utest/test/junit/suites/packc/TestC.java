package pe.edu.ulasalle.utest.test.junit.suites.packc;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("nonfun")
public class TestC {

	@Test
	void testEjecutarOperacion31() {
		fail("Not yet implemented");
	}

	@Test
	void testEjecutarOperacion32() {
		fail("Not yet implemented");
	}

	@Test
	void testEjecutarOperacion33() {
		fail("Not yet implemented");
	}

}
