package pe.edu.ulasalle.utest.test.junit.suites.packa;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TestA {

	@Test
	void testEjecutarOperacion11() {
		fail("Not yet implemented");
	}

	@Test
	void testEjecutarOperacion12() {
		fail("Not yet implemented");
	}

}
