package pe.edu.ulasalle.demo.excepciones;

public class ExceptionNotChecked extends RuntimeException {

	public ExceptionNotChecked(String msg) {
		super(msg);
	}
}
