package pe.edu.ulasalle.utest.ep;

/**
 * Utilitario para conversion a JSON, 
 * aun no terminado de implementar
 * @author Usuario
 *
 */
public class UtilitarioJson {

	public String toJson(Object obj) {
		System.out.println("Aun no implementado");
		return "";
	}
}
