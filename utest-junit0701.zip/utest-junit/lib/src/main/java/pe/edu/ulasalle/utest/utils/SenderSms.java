package pe.edu.ulasalle.utest.utils;

public class SenderSms {

	public boolean sendSms(String number, String text) {
		System.out.println("not yet implemented sms");
		return false;
	}
}
