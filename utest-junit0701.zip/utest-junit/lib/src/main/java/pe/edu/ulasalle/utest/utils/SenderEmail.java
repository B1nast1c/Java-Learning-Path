package pe.edu.ulasalle.utest.utils;

public class SenderEmail {

	public boolean sendEmail(String email, String text) {
		System.out.println("not yet implemented email");
		return false;
	}
}
