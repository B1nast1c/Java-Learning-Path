package pe.edu.ulasalle.demo.excepciones;

public class ExceptionChecked extends Exception {

	public ExceptionChecked(String msg) {
		super(msg);
	}
}
