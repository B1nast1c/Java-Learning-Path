package pe.edu.ulasalle.utest.junit.suites;

public class Clase1 {

	public int ejecutarOperacion11(String param) {
		return 11;
	}
	
	public int ejecutarOperacion12(String param) {
		return 12;
	}
}
