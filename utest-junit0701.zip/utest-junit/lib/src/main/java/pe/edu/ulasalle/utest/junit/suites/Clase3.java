package pe.edu.ulasalle.utest.junit.suites;

public class Clase3 {

	public int ejecutarOperacion31(String param) {
		return 31;
	}
	
	public int ejecutarOperacion32(String param) {
		return 32;
	}
	
	public int ejecutarOperacion33(String param) {
		return 33;
	}
}
