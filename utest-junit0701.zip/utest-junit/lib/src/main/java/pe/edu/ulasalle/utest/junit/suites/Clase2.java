package pe.edu.ulasalle.utest.junit.suites;

public class Clase2 {

	public int ejecutarOperacion21(String param) {
		return 21;
	}
	
	public int ejecutarOperacion22(String param) {
		return 22;
	}
	
	public int ejecutarOperacion23(String param) {
		return 23;
	}
}
