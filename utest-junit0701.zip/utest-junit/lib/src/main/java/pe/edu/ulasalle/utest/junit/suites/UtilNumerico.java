package pe.edu.ulasalle.utest.junit.suites;

public class UtilNumerico {

	public static boolean esImpar(int number) {
		return number % 2 != 0;
	}
	
	public static int sumar(int a, int b) {
		return a+b;
	}
	
	public static int multiplicar(int a, int b) {
		return a*b;
	}
	
	public static double dividir(int a, int b) {
		return a/b;
	}
}
