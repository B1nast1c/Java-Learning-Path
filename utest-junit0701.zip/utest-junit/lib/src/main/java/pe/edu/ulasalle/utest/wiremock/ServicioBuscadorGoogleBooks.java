package pe.edu.ulasalle.utest.wiremock;

import java.util.List;
import java.util.Map;

public class ServicioBuscadorGoogleBooks {

	public List<Map<String, Object>> buscarPublicacionesPorTitulo(String cadenaTitulo) {
		return null;
	}
}
